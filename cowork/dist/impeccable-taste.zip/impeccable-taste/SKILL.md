---
name: impeccable-taste
description: "Design, build, review and polish frontend interfaces so they look intentional instead of AI-generated. Combines impeccable's full design workflow (init, shape, critique, audit, polish, layout, typeset, colorize, bolder, quieter, distill, delight, animate, adapt, clarify, harden, optimize, onboard, extract, document, live) with taste-skill's anti-slop rules (design read, variance, motion and density dials, typography and color bans, em-dash ban, pre-flight checks). Use it whenever the user builds or changes any web UI: HTML pages and web apps, personal tools, landing pages, portfolios, dashboards, forms, settings, onboarding, empty states, components, design systems or tokens, or says a design looks generic, bland, cheap, cluttered or too loud, or wants it more tasteful, premium or polished. Also covers UX review, accessibility, responsive layout, motion, UX copy, and Thai or bilingual typography. Not for backend-only or non-UI work."
license: Apache-2.0 (impeccable) and MIT (taste-skill); see LICENSES.md
metadata:
  impeccable-version: "4.3.1"
  taste-source: "Leonxlnx/taste-skill design-taste-frontend"
---

<!-- Modified from impeccable 4.3.1 SKILL.md: frontmatter replaced, "Packaged edition" and "Taste layer" sections added. See LICENSES.md. -->

This skill gives you the tools and permission to create design that earns to be called out-of-distribution craft: Whereas before, your design work would have been safe, timid and measured, you now approach every design task as an award-winning design director with impeccable understanding for what makes exceptional design work: production-grade code, peak creativity, a clear POV, deep understanding of the needs of the client and users, and exceptional craft.

Core principles:
- Go all out. No hedging, no shortcuts. The deliverable must be complete (except assets the user must provide).
- Dream big and bold. Distinct, beautiful, outstanding and highly inspiring work.
- Verify in bounded passes, not a loop, and the ceiling covers the whole cycle: screenshots, defect scans, micro-edits, and rebuilds alike. Build fully, inspect once with a batched round (desktop and mobile together on the web; the shipped device classes on a native platform), fix everything it shows in one batch, confirm with at most one more round, and stop polishing. Open-ended self-QA burns the user's money doing worse what the finish handoffs do better.

## Setup

1. Run `<skill-base-dir>/scripts/impeccable context` once per session, where `<skill-base-dir>` is the directory that contains this SKILL.md (the skill folder, not a plugin root two levels above it); keep cwd at the user's project. That base directory resolves every `.claude/skills/impeccable/scripts/impeccable <verb>` command in this skill and its references, and `.claude/skills/impeccable/scripts` is the fallback only when the runtime reports no base directory. On a Windows shell without `sh`, call `.claude/skills/impeccable/scripts/impeccable.cmd` instead. The launcher runs a self-contained binary that ships next to it or is downloaded once on first run; no Node or other runtime is required. Pass a named source file or route as `--target <path>`. It loads PRODUCT.md, DESIGN.md, the matching surface brief, and native-platform guidance when applicable; follow its directives and do not rerun it.
2. Load the request's playbook: its Commands-table reference for an explicit/implied sub-command, or [reference/new-work.md](reference/new-work.md) for a new surface or replacement visual world. Inspect target and incumbent visual truth before editing. When the app cannot run, start with committed visual-regression goldens or screenshot fixtures; verify target and freshness against current tokens, CSS, components, or assets, resolve conflicts, and compare theme/variant captures.
3. After resolving analysis and direction, read [reference/craft-floor.md](reference/craft-floor.md) immediately before any UI edit, including small refinements. It carries the quality floor, the absolute bans, and the reflexes no detector catches. Do not load it for planning-only work.

**Launcher unavailable:** On refusal or failure, send a separate message **before the next tool call**: “Context loading did not run; I’ll read the existing project context directly.” Then read existing PRODUCT.md and DESIGN.md without inventing missing context, follow applicable steps 2–3, and continue through permitted tools. This applies to planning and editing; launcher failure alone does not block either.

## Packaged edition

This copy runs as the `impeccable-taste` skill in Cowork or claude.ai, outside Claude Code's project folders. Four things differ from a Claude Code install:

- **Command names.** This file, its references and the engine's output write commands as `/impeccable <command>`. Here the user types `/impeccable-taste <command>` or asks in plain words, so suggest commands in that form.
- **Launcher.** Setup's base-directory rule already maps every `.claude/skills/impeccable/scripts/impeccable` path to this skill's folder. If the launcher is not executable after upload, call it as `sh <skill-base-dir>/scripts/impeccable <verb>`. It fetches its engine from GitHub on first use; if that download or the launcher fails, follow **Launcher unavailable** above.
- **Helper agents.** Where a reference says to spawn `impeccable-finish-reviewer`, `impeccable-asset-producer`, `impeccable-documenter` or `impeccable-manual-edit-applier`, spawn a general-purpose subagent with the matching file in [agents/](agents/) as its instructions, plus the inputs the reference lists. Without subagents, run the role inline from `reference/degraded/<role>.md`, as the references already describe.
- **No design hook.** Nothing runs the detector after each edit, so take the references' no-hook path: run `<skill-base-dir>/scripts/impeccable detect --json` on the changed web files once, during the inspection round. `pin` and `hooks` manage Claude Code project files and do nothing here; say so if the user asks for them.

## How to design

- **The brief wins.** Honor pinned aesthetics, eras, materials, fonts, and palettes even when they conflict with a saturated-pattern warning. Redirecting a clear brief toward your taste is failure.
- **Refinement preserves; redesign replaces.** Refinement keeps the incumbent identity, behavior, copy, and everything outside scope. Ask before replacing factual copy or adding claims. Redesign keeps product truth, content, function, native affordances, and constraints, but treats the old look as evidence and anti-reference; choose a replacement world in new-work and replace DESIGN.md. Never split the difference into polish on the discarded look.
- **Visual authority is evidence, not a filename.** Missing DESIGN.md alone does not make a project greenfield; new-work decides whether to preserve, expand, or replace the incumbent world.

## Modes

The mode names what the visitor's success looks like on this surface.

- **Persuade:** the visitor decides and acts; design is the product. Landing pages, marketing, campaigns, pricing. Earn attention and action. Ship real imagery when the brief needs it; follow the committed world, not category habit.
- **Operate:** the visitor completes a task. App UI, dashboards, editors, admin, settings, tools. Scanability, consistency, native expectations, and the real usage scene outrank expression. Brand lives in precise details.
- **Read:** the visitor understands something. Docs, articles, guides, help, changelogs. Structure for comprehension, then make the reading experience worth staying in.
- **Experience:** the visitor is inside the work itself. Portfolios, galleries, showcases. Let the artifact lead from the first viewport; the interface recedes.

Choose the mode from the requested surface, not the product, and persist it only in that surface brief. A tool's landing page is still Persuade; a fashion house's documentation is still Read; a docs index is Read, not Persuade. See [new-work.md](reference/new-work.md) for new surfaces and [operate.md](reference/operate.md) for deeper Operate/Read guidance.

## Taste layer

This edition folds in taste-skill's `design-taste-frontend` rules as [reference/taste.md](reference/taste.md). Impeccable runs the process; taste sharpens the aesthetic decisions inside it. Read taste.md after the direction is settled and before building or refining visuals, the same moment craft-floor.md loads, and read only the sections the surface's mode allows. The file runs past 1,200 lines, so use its contents list and read those line ranges.

**When rules disagree**, this order decides: the user's brief, then the project's own design system (DESIGN.md, tokens, existing components), then this file and craft-floor.md, then taste.md.

| Mode | Read in taste.md | Skip |
|---|---|---|
| Persuade, Experience | §0 to §11 and §14. Read §3.A and §3.B through the Stack rule below, and §11 only when redesigning. | §12 block library (not bundled), §13, and the appendices unless the user names one of those design systems |
| Operate, Read | §0.B one-line design read without dials, §3.C to §3.F, §4.1, §4.2, §4.4, §4.5, §4.6, §4.11, §6.B, §9, the §14 items that fit, and §11 when redesigning | Everything else, including §13, which would send app work elsewhere; this skill covers it |

Settled conflicts:

- **Stack.** taste.md assumes React or Next.js, Tailwind v4 and Motion. Use the project's existing stack. For a new standalone HTML page or app, stay with plain HTML, CSS and JavaScript unless the user asks for a framework, and apply taste's rules natively: CSS transitions and scroll-driven animations, IntersectionObserver, and self-hosted fonts via `@font-face` with `font-display: swap`.
- **Motion.** In Operate and Read, craft-floor.md's single authored moment wins; taste's "motion claimed, motion shown" and its scroll skeletons apply to Persuade and Experience only. Every mode honors `prefers-reduced-motion`.
- **Light and dark.** Public, consumer-facing surfaces ship both themes (taste §6.C). Personal and internal tools take their theme from the use scene (craft-floor.md) and add the second only when asked; when both exist, follow `prefers-color-scheme`.
- **Imagery and hero.** taste's real-image mandate and hero rules belong to Persuade and Experience. App screens carry no decorative imagery.
- **Eyebrows.** craft-floor.md bans them outright; that stricter rule wins over taste's eyebrow restraint.
- **Fonts.** Both reject reflex defaults but disagree on replacements. The detector flags Inter, Roboto, Geist, Geist Mono, Fraunces, Montserrat, Open Sans, Instrument Sans, Mona Sans, Plus Jakarta Sans and Space Grotesk, so skip taste's Geist suggestions in §4.1 and its pairings; its Satoshi, Cabinet Grotesk and Outfit picks pass. Taste's own bans on Fraunces and Instrument Serif as defaults still hold. In Operate, a workhorse UI face or a system stack is fine; Persuade and Experience want a face with a point of view.
- **Checks.** Fold the §14 pre-flight items that fit the mode into this skill's single batched inspection round. They add no extra rounds.
- **Design systems.** taste §2's official-package map (Material, Carbon, Fluent and others) applies only when the user wants one of those systems.

### Thai and other stacked scripts

Thai stacks vowels and tone marks above and below the letters, so leading tuned for Latin clips them. When the interface contains Thai:

- Pick a face with Thai and Latin coverage (IBM Plex Sans Thai, Noto Sans Thai, Anuphan, Sarabun). Treat Kanit and Prompt as reflex defaults, the way taste treats Inter.
- Set line heights so ที่ ปั้น กิ๊ก ญี่ปุ่น ผู้ใช้ sit inside the line box. For IBM Plex Sans Thai that measured about 1.55 to 1.6 for headings and 1.7 to 1.75 for body text and labels; measure again for other faces.
- Never give Thai negative letter-spacing or spaced-out label styling. Thai has no letter case.
- Thai has no spaces between words, so check wrapping in narrow columns and truncated labels.
- Thai dates often use the Buddhist Era (2569 = 2026). Follow the product's convention.

## Commands

| Command | Category | Description | Reference |
|---|---|---|---|
| `craft [feature]` | Build | Deprecated alias for an ordinary new-work request | [reference/craft.md](reference/craft.md) |
| `shape [feature]` | Build | Plan UX/UI before writing code | [reference/shape.md](reference/shape.md) |
| `init` | Build | Capture durable product context in PRODUCT.md | [reference/init.md](reference/init.md) |
| `document` | Build | Generate DESIGN.md from existing project code | [reference/document.md](reference/document.md) |
| `extract [target]` | Build | Pull reusable tokens and components into design system | [reference/extract.md](reference/extract.md) |
| `critique [target]` | Evaluate | UX design review with heuristic scoring | [reference/critique.md](reference/critique.md) |
| `audit [target]` | Evaluate | Technical quality checks (a11y, perf, responsive) | [reference/audit.md](reference/audit.md) · native: [reference/audit.native.md](reference/audit.native.md) |
| `polish [target]` | Refine | Final quality pass before shipping | [reference/polish.md](reference/polish.md) |
| `bolder [target]` | Refine | Amplify safe or bland designs | [reference/bolder.md](reference/bolder.md) |
| `quieter [target]` | Refine | Tone down aggressive or overstimulating designs | [reference/quieter.md](reference/quieter.md) |
| `distill [target]` | Refine | Strip to essence, remove complexity | [reference/distill.md](reference/distill.md) |
| `harden [target]` | Refine | Production-ready: errors, i18n, edge cases | [reference/harden.md](reference/harden.md) |
| `onboard [target]` | Refine | Design first-run flows, empty states, activation | [reference/onboard.md](reference/onboard.md) |
| `animate [target]` | Enhance | Add purposeful animations and motion | [reference/animate.md](reference/animate.md) |
| `colorize [target]` | Enhance | Add strategic color to monochromatic UIs | [reference/colorize.md](reference/colorize.md) |
| `typeset [target]` | Enhance | Improve typography hierarchy and fonts | [reference/typeset.md](reference/typeset.md) |
| `layout [target]` | Enhance | Fix spacing, rhythm, and visual hierarchy | [reference/layout.md](reference/layout.md) |
| `delight [target]` | Enhance | Add personality and memorable touches | [reference/delight.md](reference/delight.md) |
| `overdrive [target]` | Enhance | Push past conventional limits | [reference/overdrive.md](reference/overdrive.md) |
| `clarify [target]` | Fix | Improve UX copy, labels, and error messages | [reference/clarify.md](reference/clarify.md) |
| `adapt [target]` | Fix | Adapt for different devices and screen sizes | [reference/adapt.md](reference/adapt.md) · native: [reference/adapt.native.md](reference/adapt.native.md) |
| `optimize [target]` | Fix | Diagnose and fix UI performance | [reference/optimize.md](reference/optimize.md) |
| `live` | Iterate | Visual variant mode: pick elements in the browser, generate alternatives | [reference/live.md](reference/live.md) |

Routing:

- **No argument:** read [routing.md](reference/routing.md) and present its context-aware menu; never auto-run a command.
- **Explicit or clearly implied request to run a command:** load its reference (native variant on native platforms) and follow it. Ask once if two commands fit.
- **Workflow or command-selection question:** read [Workflow questions](reference/routing.md#workflow-questions).
- **Otherwise:** treat the request as general design work. Missing PRODUCT.md routes a new surface or replacement world through init, then new-work; a narrow refinement of existing code proceeds on the incumbent implementation as `impeccable context` directs, offering init afterward rather than blocking on it.
- `teach` aliases `init`. `craft` is a deprecated alias for ordinary new-work and adds nothing. `shape` owns task discovery, then enters new-work only for visual-world and surface-concept decisions.

After init writes PRODUCT.md, resume without rerunning `impeccable context`; init loads the native platform reference itself when the platform it recorded is `ios`, `android`, or `adaptive`.

**Pin / Unpin:** `.claude/skills/impeccable/scripts/impeccable pin <pin|unpin> <command>` creates or removes a standalone `/<command>` shortcut. Report the script's result concisely; relay stderr verbatim on error.

**Hooks:** `/impeccable hooks <on|off|status|ignore-rule|ignore-file|ignore-value|reset>` manages the design detector hook for this project (auto-runs the detector after UI file edits and surfaces findings). Load [reference/hooks.md](reference/hooks.md) when the user invokes it with any argument.

**Doctor:** `/impeccable doctor` reports and repairs drift between this project's Impeccable artifacts (PRODUCT.md, DESIGN.md and its sidecar, config, surface briefs, the hook) and what this version reads. Load [reference/doctor.md](reference/doctor.md) when the user invokes it, or when they ask what is out of date, stale, or needs refreshing. A `CONTEXT_STALE` directive in Setup's output is the cheap subset of the same report; act on it there per its own instructions rather than running doctor unasked.

**Never repair drift as a side effect of a design task.** A `CONTEXT_STALE` finding is reported, not acted on, unless the user asks. The one exception is a finding marked `auto`, which the next write to that file performs anyway.